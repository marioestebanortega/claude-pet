#!/bin/bash
# OPCIONAL: instala el hook de statusLine para que Claude Pet reciba datos aún más frescos.
# No consume cuota. Hace copia de seguridad de settings.json antes de tocarlo.
set -euo pipefail
SRC="$(cd "$(dirname "$0")" && pwd)/statusline-pet.py"

python3 - "$SRC" <<'PY'
import json, os, shutil, sys, time
src = sys.argv[1]
dst = os.path.expanduser("~/.claude/statusline-pet.py")
prev = os.path.expanduser("~/.claude/claudepet-prev-statusline.json")
shutil.copyfile(src, dst); os.chmod(dst, 0o755)

s = os.path.expanduser("~/.claude/settings.json")
cfg = {}
if os.path.exists(s):
    shutil.copyfile(s, s + f".bak.{int(time.time())}")
    try:
        cfg = json.load(open(s))
    except ValueError:
        print(f"❌ {s} no es JSON válido. Se dejó una copia (.bak.*) y no se tocó nada.")
        sys.exit(1)
    if not isinstance(cfg, dict):
        print(f"❌ {s} no es un objeto JSON. Se dejó una copia (.bak.*) y no se tocó nada.")
        sys.exit(1)

old = cfg.get("statusLine")
mine = isinstance(old, dict) and old.get("command", "").endswith("statusline-pet.py")
if isinstance(old, dict) and not mine:
    # Había un statusLine ajeno: se guarda aparte para poder restaurarlo al
    # desinstalar. No se pisa un sidecar previo (una reinstalación no debe
    # perder el original de la primera vez).
    if not os.path.exists(prev):
        json.dump(old, open(prev, "w"), indent=2)
    print(f"⚠️  Ya tenías un statusLine propio:\n    {old.get('command')}\n"
          f"    Se guardó en {prev} y se restaura con ./uninstall-statusline.sh.")

cfg["statusLine"] = {
    "type": "command",
    "command": f"python3 {dst}",
    # Sin esto, la línea de estado solo se re-ejecuta tras cada mensaje del
    # asistente: si dejas Claude Code quieto, el dato de cuota se congela.
    # Con refreshInterval también corre en temporizador. Mínimo permitido: 1.
    "refreshInterval": 10,
    "padding": 1,
}
# Escritura atómica: nunca dejar el settings.json a medio escribir.
tmp = s + ".tmp"
json.dump(cfg, open(tmp, "w"), indent=2)
os.replace(tmp, s)
print("✅ statusLine instalado. Reinicia Claude Code para verlo.")
PY
